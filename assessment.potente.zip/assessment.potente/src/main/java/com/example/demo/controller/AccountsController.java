package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Accounts;
import com.example.demo.model.Room;
import com.example.demo.repository.AccountRepo;

@Controller
public class AccountsController {
	
	@Autowired
	AccountRepo repo;
	
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	
	//Login
	@PostMapping(value = "/login")
	public ModelAndView login(@ModelAttribute Accounts accounts, HttpSession session) {
		List<Accounts> userList = repo.findAll();
		for(Accounts check : userList) {
			session.setAttribute("id", check.getId());
			session.setAttribute("firstName", check.getFirstName());
			session.setAttribute("lastName", check.getLastName());
			session.setAttribute("accessType", check.getAccessType());
			if(accounts.getUsername().equals(check.getUsername()) && 
					accounts.getPassword().equals(check.getPassword())) {
				if(check.getAccessType().equals("admin")) {
					return new ModelAndView("redirect:/show");
				} else if (check.getAccessType().equals("staff")){
					return new ModelAndView("redirect:/showRooms");
				}else if (check.getAccessType().equals("client")){
					return new ModelAndView("redirect:/showToClient");
				}		
			}	
		}
		return new ModelAndView("home.jsp");
	}
	
	//Show users
	@RequestMapping("/show")
	public ModelAndView show(ModelAndView modelView, Model model, HttpSession session){
		List<Accounts> accounts = repo.findAll();
		modelView.addObject("list", accounts);
		model.addAttribute("firstName", session.getAttribute("firstName"));
		model.addAttribute("id", session.getAttribute("id"));
		modelView.setViewName("adminPage.jsp");
		return modelView;
	}
	
	@RequestMapping("/goToForm")
	public String toForm() {
		return "newAccount.jsp";
	}
	
	
	@RequestMapping("/update/{id}")
	public String update(Accounts account, @PathVariable("id") final Integer id){		
		repo.save(account);
	    return "redirect:/show";		
	}

	//Add user
	@RequestMapping("/addAccount")
	public String addTicket(Accounts account) {
		repo.save(account);
		return "redirect:/show";
	}
	
	//Delete user 
	@GetMapping("/delete/{id}")
	public ModelAndView delete(@PathVariable final Integer id, ModelAndView modelView){		
		repo.deleteById(id);
		modelView = new ModelAndView("redirect:/show");
		return modelView;
	}
	

	
}
