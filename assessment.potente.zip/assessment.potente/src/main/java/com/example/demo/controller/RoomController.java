package com.example.demo.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.Accounts;
import com.example.demo.model.Reservation;
import com.example.demo.model.Room;
import com.example.demo.repository.ReserveRepo;
import com.example.demo.repository.RoomRepo;

import com.example.demo.controller.AccountsController;


@Controller
public class RoomController {
	
	@Autowired
	RoomRepo repo;
	
	@Autowired
	ReserveRepo reserve;
	
	//Show users
	@RequestMapping("/showRooms")
	public ModelAndView show(ModelAndView modelView){
		List<Room> room = repo.findAll();
		modelView.addObject("list", room);
		modelView.setViewName("staffPage.jsp");
		return modelView;
	}
	
	@RequestMapping("/showReserveAdmin")
	public ModelAndView showReserveAdmin(ModelAndView modelView){
		List<Room> room = repo.findAll();
		modelView.addObject("list", room);
		modelView.setViewName("clientPage.jsp");
		return modelView;
	}
	
	@RequestMapping("/showToClient")
	public ModelAndView showToClient(ModelAndView modelView, HttpSession session){
		session.getAttribute("id");
		List<Room> room = repo.findAll();
		modelView.addObject("list", room);
		modelView.setViewName("clientPage.jsp");
		return modelView;	
	}
	
	//Show reserved rooms
	@RequestMapping("/showReservedRooms")
	public ModelAndView showReservedRooms(ModelAndView modelView){
		List<Reservation> reservation = reserve.findAll();
		modelView.addObject("list", reservation);
		modelView.setViewName("reservedRooms.jsp");
		return modelView;	
	}
	
	//Add room
	@RequestMapping("/addRoom")
	public String addTicket(Room room) {
		repo.save(room);
		return "redirect:/showRooms";
	}
	
	@RequestMapping("/goToAddRoom")
	public String toForm() {
		return "newRoom.jsp";
	}
	
	//Delete room
	@GetMapping("/deleteRoom/{id}")
	public ModelAndView delete(@PathVariable final Integer id, ModelAndView modelView){		
		repo.deleteById(id);
		modelView = new ModelAndView("redirect:/showRooms");
		return modelView;
	}
	
	//Update room
	@RequestMapping("/updateRoom/{id}")
	public String updateRoom(Room room, @PathVariable("id") final Integer id){		
		repo.save(room);
	    return "redirect:/showRooms";		
	}
	
	@RequestMapping("/updateRoomSample")
	public String updateRoomModal(@RequestParam("id") Integer id, @RequestParam("roomNumber") Integer roomNumber, @RequestParam("roomType") String roomType, @RequestParam("roomStatus") String roomStatus, @RequestParam("price") Double price){		
		Room room = repo.findById(id).orElse(null);
		if(room == null) {
			return "show";
		}
		room.setRoomNumber(roomNumber);
		room.setRoomType(roomType);
		room.setRoomStatus(roomStatus);
		room.setPrice(price);
		repo.save(room);
	    return "redirect:/showRooms";		
	}
	
	//Reserve room
	@RequestMapping("/reserve/{id}")
	public String reserveRoom(@PathVariable("id") Integer id, @RequestParam("room") Room room,
							@RequestParam("reserveFrom") String reserveFrom,
							@RequestParam("reserveTo") String reserveTo,
							@RequestParam("name") String name,
							@RequestParam("totalAmount") Double totalAmount,
							@RequestParam("account") Accounts account){		
		Reservation reservation = new Reservation();
		reservation.setId(id);
		reservation.setName(name);
		reservation.setRoom(room);
		reservation.setTotalAmount(totalAmount);
		reservation.setAccount(account);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-mm-dd");
		Date parsedFrom;
		Date parsedTo;
		try {
			parsedFrom = format.parse(reserveFrom);
			reservation.setReserveFrom(parsedFrom);
			parsedTo = format.parse(reserveTo);
			reservation.setReserveTo(parsedTo);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		reserve.save(reservation);
		return "redirect:/showReservedRooms";		
	}
	
	//Delete room
		@GetMapping("/deleteReservation/{id}")
		public ModelAndView deleteReservation(@PathVariable final Integer id, ModelAndView modelView){		
			reserve.deleteById(id);
			modelView = new ModelAndView("redirect:/showReservedRooms");
			return modelView;
		}
	

	
}
