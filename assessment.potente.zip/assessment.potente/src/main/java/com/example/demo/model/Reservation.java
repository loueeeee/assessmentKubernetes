package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Reservation {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
	
    @OneToOne
    @JoinColumn(name="room_id")
    private Room room;

    private Date reserveFrom;

    private Date reserveTo;
    
    private String name;
    
    private Double totalAmount;
    
    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="account_id")
    private Accounts account;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}



	public Date getReserveFrom() {
		return reserveFrom;
	}

	public void setReserveFrom(Date reserveFrom) {
		this.reserveFrom = reserveFrom;
	}

	public Date getReserveTo() {
		return reserveTo;
	}

	public void setReserveTo(Date reserveTo) {
		this.reserveTo = reserveTo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}


	public Accounts getAccount() {
		return account;
	}

	public void setAccount(Accounts account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Reservation [id=" + id + ", room=" + room + ", reserveFrom=" + reserveFrom + ", reserveTo=" + reserveTo
				+ ", name=" + name + ", totalAmount=" + totalAmount + ", account=" + account + "]";
	}

	public Reservation() {
		super();
	}
    
    
}
