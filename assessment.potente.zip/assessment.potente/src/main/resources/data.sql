insert into accounts values (1001, 'admin', 'Loue', 'Potente', 'password' ,'louepotente');
insert into accounts values (1002, 'staff', 'Glen', 'Santos', 'password' ,'glensantos');
insert into accounts values (1003, 'client', 'Jan', 'Perez', 'password' ,'janperez');
insert into room values (2001, 10000, 1, 'Open', 'King');
insert into room values (2002, 8000, 2, 'Open', 'Queen');
insert into room values (2003, 3000, 3, 'Open', 'Single');
insert into room values (2004, 5000, 4, 'Open', 'Double');
insert into room values (2005, 5000, 5, 'Open', 'Double');